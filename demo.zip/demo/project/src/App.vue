<template>
  <div id="app">
    <homeView></homeView>
  </div>
</template>

<script>
import homeView from './view/homeView.vue'

export default {
  name: 'App',
  components: {
    homeView
  }
}
</script>
